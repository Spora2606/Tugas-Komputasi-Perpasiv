/**
 * app.js
 * ─────────────────────────────────────────────────────────────
 * File utama logika aplikasi SmartExam.
 * Berisi semua fitur pervasif:
 *   1. Tab Visibility Monitor  → mendeteksi pindah tab
 *   2. Idle / AFK Detector     → mendeteksi pengguna tidak aktif
 *   3. Timer ujian             → countdown + auto-submit
 *   4. Navigasi soal           → render soal & jawaban
 *   5. Halaman hasil           → skor + log perilaku
 * ─────────────────────────────────────────────────────────────
 */

/* ══════════════════════════════════════
   KONFIGURASI
══════════════════════════════════════ */
const CONFIG = {
  EXAM_DURATION_SEC : 180,  // durasi ujian dalam detik (3 menit)
  AFK_THRESHOLD_SEC : 20,   // detik tidak aktif → dianggap AFK
  MAX_TAB_SWITCHES  : 3,    // maks pindah tab sebelum ujian dikunci
};

/* ══════════════════════════════════════
   STATE APLIKASI
   Semua variabel kondisi ujian ada di sini
══════════════════════════════════════ */
let state = {
  studentName  : '',
  studentNim   : '',
  currentQ     : 0,           // indeks soal aktif
  answers      : [],          // jawaban user per soal
  timeLeft     : CONFIG.EXAM_DURATION_SEC,
  tabSwitches  : 0,           // hitung pindah tab
  afkSeconds   : 0,           // akumulasi detik AFK
  idleCount    : 0,           // counter detik idle saat ini
  isAfk        : false,
  isLocked     : false,
  examStarted  : false,
  behaviorLog  : [],          // log kejadian [{ts, msg, type}]
  examStartTime: null,
};

/* ══════════════════════════════════════
   INTERVAL & TIMER HANDLES
══════════════════════════════════════ */
let timerInterval = null;
let idleInterval  = null;
let toastTimeout  = null;
let afkInterval   = null;

/* ══════════════════════════════════════
   1. NAVIGASI HALAMAN
══════════════════════════════════════ */
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

/* ══════════════════════════════════════
   2. MULAI UJIAN
══════════════════════════════════════ */
function startExam() {
  const name = document.getElementById('inp-name').value.trim();
  const nim  = document.getElementById('inp-nim').value.trim();

  if (!name || !nim) {
    showToast('Isi nama dan NIM terlebih dahulu!', 2500);
    return;
  }

  // reset semua state
  state = {
    studentName  : name,
    studentNim   : nim,
    currentQ     : 0,
    answers      : new Array(QUESTIONS.length).fill(null),
    timeLeft     : CONFIG.EXAM_DURATION_SEC,
    tabSwitches  : 0,
    afkSeconds   : 0,
    idleCount    : 0,
    isAfk        : false,
    isLocked     : false,
    examStarted  : true,
    behaviorLog  : [],
    examStartTime: new Date(),
  };

  addLog('Ujian dimulai', 'ok');
  showPage('page-exam');
  renderQuestion();
  startTimer();
  startIdleDetector();
  startTabMonitor();
}

/* ══════════════════════════════════════
   3. RENDER SOAL
══════════════════════════════════════ */
function renderQuestion() {
  const q     = QUESTIONS[state.currentQ];
  const total = QUESTIONS.length;
  const letters = ['A', 'B', 'C', 'D'];

  // teks soal
  document.getElementById('q-num').textContent  = `Soal ${state.currentQ + 1}`;
  document.getElementById('q-text').textContent = q.text;

  // render opsi
  const opts = document.getElementById('q-options');
  opts.innerHTML = '';
  q.options.forEach((opt, i) => {
    const div = document.createElement('div');
    div.className = 'option' + (state.answers[state.currentQ] === i ? ' selected' : '');
    div.innerHTML = `<div class="opt-letter">${letters[i]}</div><span>${opt}</span>`;
    div.onclick   = () => selectAnswer(i);
    opts.appendChild(div);
  });

  // update progress bar
  const answered = state.answers.filter(a => a !== null).length;
  const pct      = Math.round((answered / total) * 100);
  document.getElementById('prog-fill').style.width  = pct + '%';
  document.getElementById('prog-pct').textContent   = pct + '%';
  document.getElementById('prog-label').textContent = `Soal ${state.currentQ + 1} dari ${total}`;

  // tombol navigasi
  document.getElementById('btn-prev').disabled = state.currentQ === 0;
  const isLast = state.currentQ === total - 1;
  document.getElementById('btn-next').style.display   = isLast ? 'none' : '';
  document.getElementById('btn-finish').style.display = isLast ? '' : 'none';
}

function selectAnswer(i) {
  if (state.isLocked) return;
  state.answers[state.currentQ] = i;
  renderQuestion();
}

function goQuestion(dir) {
  const next = state.currentQ + dir;
  if (next < 0 || next >= QUESTIONS.length) return;
  state.currentQ = next;
  renderQuestion();
}

/* ══════════════════════════════════════
   4. TIMER UJIAN
══════════════════════════════════════ */
function startTimer() {
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    // jangan hitung mundur saat AFK atau terkunci
    if (state.isAfk || state.isLocked) return;

    state.timeLeft--;
    if (state.timeLeft <= 0) {
      state.timeLeft = 0;
      updateTimerDisplay();
      addLog('Waktu ujian habis', 'warn');
      finishExam(false);
      return;
    }
    updateTimerDisplay();
  }, 1000);
}

function updateTimerDisplay() {
  const m  = String(Math.floor(state.timeLeft / 60)).padStart(2, '0');
  const s  = String(state.timeLeft % 60).padStart(2, '0');
  const el = document.getElementById('timer-display');
  el.textContent = `${m}:${s}`;
  // warna merah berkedip saat sisa < 30 detik
  el.classList.toggle('danger', state.timeLeft <= 30);
}

/* ══════════════════════════════════════
   5. FITUR PERVASIF #1
      TAB VISIBILITY MONITOR (Anti-Cheating)
      Menggunakan Page Visibility API bawaan browser
══════════════════════════════════════ */
function startTabMonitor() {
  // hapus listener lama agar tidak dobel
  document.removeEventListener('visibilitychange', handleVisibilityChange);
  document.addEventListener('visibilitychange', handleVisibilityChange);
}

function handleVisibilityChange() {
  if (!state.examStarted || state.isLocked) return;

  if (document.hidden) {
    // pengguna PINDAH ke tab lain
    state.tabSwitches++;
    document.getElementById('vio-badge').textContent = state.tabSwitches + '×';
    addLog(`Pindah tab ke-${state.tabSwitches}`, 'err');
    showToast(`⚠️ Peringatan ${state.tabSwitches}/${CONFIG.MAX_TAB_SWITCHES}: Jangan berpindah tab!`, 3500);

    // kunci ujian jika sudah melebihi batas
    if (state.tabSwitches >= CONFIG.MAX_TAB_SWITCHES) {
      addLog('Ujian dikunci – batas pelanggaran tab terlampaui', 'err');
      lockExam();
    }
  } else {
    // pengguna KEMBALI ke tab ujian
    addLog('Kembali ke tab ujian', 'ok');
  }
}

function lockExam() {
  state.isLocked = true;
  clearInterval(timerInterval);
  clearInterval(idleInterval);
  document.getElementById('lock-overlay').classList.add('show');
}

/* ══════════════════════════════════════
   6. FITUR PERVASIF #2
      IDLE / AFK DETECTOR (Presence Tracker)
      Mendeteksi mouse, keyboard, touch, scroll
══════════════════════════════════════ */
function startIdleDetector() {
  clearInterval(idleInterval);
  state.idleCount = 0;

  // setiap detik: tambah counter idle
  idleInterval = setInterval(() => {
    if (state.isLocked || !state.examStarted) return;
    if (!state.isAfk) {
      state.idleCount++;
      if (state.idleCount >= CONFIG.AFK_THRESHOLD_SEC) {
        triggerAfk();
      }
    }
  }, 1000);

  // pasang event listener aktivitas pengguna
  const activityEvents = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'];
  activityEvents.forEach(evt => document.addEventListener(evt, resetIdleCounter));
}

function resetIdleCounter() {
  if (!state.examStarted) return;
  state.idleCount = 0;  // reset counter setiap ada aktivitas
  if (state.isAfk) resumeFromAfk();
}

function triggerAfk() {
  if (state.isAfk || state.isLocked) return;
  state.isAfk     = true;
  state.afkSeconds = 0;

  // tampilkan overlay AFK
  document.getElementById('afk-overlay').classList.add('show');
  // ubah indikator status menjadi kuning
  document.getElementById('dot-presence').className = 'status-dot dot-yellow';
  document.getElementById('txt-presence').textContent = 'AFK';

  addLog(`Terdeteksi AFK (tidak aktif ${CONFIG.AFK_THRESHOLD_SEC} detik)`, 'warn');

  // hitung berapa lama AFK
  afkInterval = setInterval(() => {
    if (!state.isAfk) { clearInterval(afkInterval); return; }
    state.afkSeconds++;
  }, 1000);
}

function resumeFromAfk() {
  state.isAfk = false;
  clearInterval(afkInterval);
  state.idleCount = 0;

  // tutup overlay AFK
  document.getElementById('afk-overlay').classList.remove('show');
  // kembalikan indikator status ke hijau
  document.getElementById('dot-presence').className = 'status-dot dot-green';
  document.getElementById('txt-presence').textContent = 'Hadir';

  if (state.afkSeconds > 0) {
    addLog(`Kembali aktif setelah AFK ${state.afkSeconds} detik`, 'ok');
  }
}

/* ══════════════════════════════════════
   7. SELESAI UJIAN & TAMPILKAN HASIL
══════════════════════════════════════ */
function finishExam(forced) {
  state.examStarted = false;

  // hentikan semua interval
  clearInterval(timerInterval);
  clearInterval(idleInterval);
  clearInterval(afkInterval);

  // lepas event listener tab monitor
  document.removeEventListener('visibilitychange', handleVisibilityChange);

  // tutup semua overlay
  document.getElementById('afk-overlay').classList.remove('show');
  document.getElementById('lock-overlay').classList.remove('show');

  if (forced) addLog('Ujian dihentikan paksa (terlalu banyak pelanggaran tab)', 'err');
  else        addLog('Ujian diselesaikan oleh pengguna', 'ok');

  // hitung skor
  let score = 0;
  state.answers.forEach((a, i) => {
    if (a === QUESTIONS[i].answer) score++;
  });
  const pct  = Math.round((score / QUESTIONS.length) * 100);
  const pass = pct >= 60;

  // ── render score ring ──
  const ringColor = pass ? 'var(--success)' : 'var(--danger)';
  const ringGlow  = pass ? 'rgba(16,185,129,.3)' : 'rgba(239,68,68,.3)';
  document.getElementById('score-ring-wrap').innerHTML = `
    <div class="score-ring" style="border-color:${ringColor};box-shadow:0 0 40px ${ringGlow}">
      <span>${pct}<span class="score-label">%</span></span>
    </div>`;

  // ── info mahasiswa ──
  document.getElementById('student-info').innerHTML = `
    <div style="font-weight:600;font-size:1.1rem">${state.studentName}</div>
    <div style="color:var(--muted);font-size:.85rem">
      NIM: ${state.studentNim} &nbsp;|&nbsp; Benar: ${score}/${QUESTIONS.length}
    </div>`;

  // ── verdict ──
  let verdictText = '';
  if (forced) {
    verdictText = `Ujian dihentikan paksa karena berpindah tab ${CONFIG.MAX_TAB_SWITCHES}× atau lebih. Skor dihitung dari jawaban yang sudah masuk.`;
  } else if (pass) {
    verdictText = `🎉 Selamat! Anda lulus dengan skor ${pct}%. Pertahankan integritas akademik Anda!`;
  } else {
    verdictText = `Skor Anda ${pct}% – di bawah batas kelulusan (60%). Pelajari kembali materi dan coba lagi.`;
  }
  const vbox = document.getElementById('verdict-box');
  vbox.textContent = verdictText;
  vbox.className   = 'verdict ' + (pass && !forced ? 'verdict-pass' : 'verdict-fail');

  // ── log perilaku ──
  const tbody = document.getElementById('log-body');
  tbody.innerHTML = '';
  state.behaviorLog.forEach(l => {
    const cls  = l.type === 'ok' ? 'log-ok' : l.type === 'warn' ? 'log-warn' : 'log-err';
    const icon = l.type === 'ok' ? '✅' : l.type === 'warn' ? '⚠️' : '❌';
    tbody.innerHTML += `
      <tr>
        <td style="font-family:var(--mono);font-size:.8rem;color:var(--muted)">${l.ts}</td>
        <td>${l.msg}</td>
        <td class="${cls}">${icon}</td>
      </tr>`;
  });

  // baris ringkasan
  const totalAfk = state.behaviorLog
    .filter(l => l.msg.includes('Kembali aktif setelah AFK'))
    .reduce((sum, l) => {
      const m = l.msg.match(/(\d+) detik/);
      return sum + (m ? parseInt(m[1]) : 0);
    }, 0);

  tbody.innerHTML += `
    <tr style="background:rgba(30,45,69,.4)">
      <td colspan="3" style="padding:.75rem;font-size:.82rem;color:var(--muted)">
        Ringkasan: Pindah tab <strong>${state.tabSwitches}×</strong>
        · Total AFK ≈ <strong>${totalAfk} detik</strong>
        · Sisa waktu: <strong>${Math.floor(state.timeLeft/60)}m ${state.timeLeft%60}s</strong>
      </td>
    </tr>`;

  showPage('page-result');
}

/* ══════════════════════════════════════
   8. RESET / ULANGI UJIAN
══════════════════════════════════════ */
function resetExam() {
  document.getElementById('inp-name').value = '';
  document.getElementById('inp-nim').value  = '';
  showPage('page-start');
}

/* ══════════════════════════════════════
   9. HELPER – TOAST NOTIFIKASI
══════════════════════════════════════ */
function showToast(msg, duration = 3000) {
  const toast = document.getElementById('toast');
  document.getElementById('toast-msg').textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), duration);
}

/* ══════════════════════════════════════
   10. HELPER – TAMBAH LOG PERILAKU
══════════════════════════════════════ */
function addLog(msg, type) {
  const ts = new Date().toLocaleTimeString('id-ID', { hour12: false });
  state.behaviorLog.push({ ts, msg, type });
}
