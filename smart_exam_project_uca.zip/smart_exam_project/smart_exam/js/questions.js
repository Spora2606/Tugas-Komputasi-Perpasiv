/**
 * questions.js
 * ─────────────────────────────────────────────────────────────
 * File ini berisi BANK SOAL ujian.
 * Untuk menambah/mengubah soal, cukup edit array QUESTIONS ini.
 *
 * Format setiap soal:
 * {
 *   text   : "Teks pertanyaan",
 *   options: ["Pilihan A", "Pilihan B", "Pilihan C", "Pilihan D"],
 *   answer : 0  ← index jawaban benar (0=A, 1=B, 2=C, 3=D)
 * }
 * ─────────────────────────────────────────────────────────────
 */

const QUESTIONS = [
  {
    text: "Apa yang dimaksud dengan 'Pervasive Computing' (Komputasi Pervasif)?",
    options: [
      "Komputasi yang hanya terjadi di pusat data besar",
      "Integrasi komputasi ke dalam lingkungan sehari-hari secara tak kasat mata",
      "Penggunaan komputer desktop untuk produktivitas",
      "Sistem operasi berbasis cloud yang terpusat"
    ],
    answer: 1
  },
  {
    text: "API manakah yang digunakan untuk mendeteksi apakah tab browser sedang aktif atau tersembunyi?",
    options: [
      "Geolocation API",
      "Web Storage API",
      "Page Visibility API",
      "Notification API"
    ],
    answer: 2
  },
  {
    text: "Event JavaScript apa yang paling tepat digunakan untuk mendeteksi keaktifan (presence) pengguna di halaman web?",
    options: [
      "onclick dan onsubmit",
      "mousemove, keypress, dan touchstart",
      "onload dan onresize",
      "scroll dan DOMContentLoaded"
    ],
    answer: 1
  },
  {
    text: "Dalam konteks Context-Aware System, apa fungsi dari 'Presence Tracker'?",
    options: [
      "Melacak lokasi GPS pengguna secara real-time",
      "Mendeteksi apakah pengguna sedang aktif berinteraksi dengan perangkat",
      "Menyimpan riwayat sesi login pengguna",
      "Menampilkan notifikasi push pada browser"
    ],
    answer: 1
  },
  {
    text: "Properti JavaScript yang bernilai 'true' ketika tab browser TIDAK sedang dilihat pengguna adalah...",
    options: [
      "document.tabHidden",
      "window.isBackground",
      "document.hidden",
      "navigator.tabVisible"
    ],
    answer: 2
  }
];
